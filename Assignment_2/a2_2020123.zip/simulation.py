# Name - Shivam Agarwal
# Roll No - 2020123

'''
- This is the skeleton code, wherein you have to write the logic for each of the
functions defined below.

- DO NOT modify/delete the given functions. 

- DO NOT import any python libraries. You may only import a2.py.

- Make sure to return value as specified in the function description.

- Remove the pass statement from the function when you implement it.

- Do not create any global variables in this module.
'''


# Write the code here for creating an interactive program.

import a2

print("="*40)
print('             STUDENT CENTRE')
print('='*40)
print('\nHello! Welcome To The Student Centre')
records = []

while True :
    print('\n'+'-'*40)
    print("Which Query Would You Like to Perform?")
    print('-'*40+'\n')
    print('1) Read data from file')
    print('2) Filter by first name')
    print('3) Filter by last name')
    print('4) Filter by full name')
    print('5) Filter by age range')
    print('6) Count by gender')
    print('7) Filter by address')
    print('8) Find alumni')
    print('9) Find topper of each institue')
    print('10) Find Blood donors')
    print('11) Get common friends')
    print('12) Is related')
    print('13) Delete by ID')
    print('14) Add friend')
    print('15) Remove friend')
    print('16) Add Education')
    n = int(input('\nEnter Query Code (-1 to exit) : '))

    if (n == -1):
        print('\n','='*40,'Thank You For Visiting!','='*40)
        break
    elif n in range(1,17):
        if(n == 1):
            records = a2.read_data_from_file()
            for i in range(len(records)):
                print(records[i])


        elif(n == 2):
            name = input("Enter first name : ")
            print(a2.filter_by_first_name(records,name))
        
        elif(n == 3):
            name = input("Enter last name : ")
            print(a2.filter_by_last_name(records,name))

        elif(n == 4):
            name = input("Enter full name : ")
            print(a2.filter_by_full_name(records,name))

        elif(n == 5):
            min_age = int(input('Enter minimum age : '))
            max_age = int(input('Enter maximum age : '))
            print(a2.filter_by_age_range(records,min_age,max_age))

        elif(n == 6):
            gender = a2.count_by_gender(records)
            print("Number of males :",gender['male'])
            print('Number of females :',gender['female'])

        elif(n == 7):

            address = {}
            while True:
                try :
                    temp = input('Enter House number (otherwise leave blank): ')
                    if (temp == ''):
                        break
                    address['house_no'] = int(temp)
                    break
                except ValueError:
                    print("incorrect house number, Try again") 
            
            temp = input("Enter block (otherwise leave blank): ")
            if(temp == ''):
                pass
            else :
                address['block'] = temp


            temp = input("Enter town (otherwise leave blank): ")
            if(temp == ''):
                pass
            else :
                address['town'] = temp

            temp = input("Enter city (otherwise leave blank): ")
            if(temp == ''):
                pass
            else :
                address['city'] = temp

            temp = input("Enter state (otherwise leave blank): ")
            if(temp == ''):
                pass
            else :
                address['state'] = temp

            while True:
                try :
                    temp = input('Enter Pincode (otherwise leave blank): ')
                    if (temp == ''):
                        break
                    address['pincode'] = int(temp)
                    break
                except ValueError:
                    print("incorrect pincode, Try again") 
            
            names = a2.filter_by_address(records,address)
            print()
            for i in names:
                print(i)
        
        elif(n == 8):

            n = input('Enter institute name : ')
            alumni = a2.find_alumni(records,n)
            print()

            for i in alumni:
                print(i)

        elif(n == 9):

            n = a2.find_topper_of_each_institute(records)

            for i in n :
                print('Institute :',i,',Topper ID :',n[i])

        elif(n == 10):

            reciever_id = int(input('Enter ID of person needing blood : '))
            donors = a2.find_blood_donors(records,reciever_id)

            for i in donors:
                print('ID :',i,', Contact numbers :',donors[i])
        
        elif(n == 11):

            n = list(map(int,input('Enter the IDs(space separated)').split()))
            common_friends = a2.get_common_friends(records,n)
            print(common_friends)

        elif(n == 12):

            id1 = int(input("Enter ID of person 1 : "))
            id2 = int(input("Enter ID of person 2 : "))

            if a2.is_related(records,id1,id2):
                print("\nthe people are related")
            else :
                print("\nthe people are not related")

        elif(n == 13):

            n = int(input('Enter the ID of the person whose record is to be deleted : '))
            records = a2.delete_by_id(records,n)

            for i in range(len(records)):
                print(records[i])

        elif(n == 14):

            id1 = int(input("Enter ID of person 1 to be added as friend : "))
            id2 = int(input("Enter ID of person 2 to be added as friend: "))

            records = a2.add_friend(records,id1,id2)

            for i in range(len(records)):
                print(records[i])

        elif(n == 15):

            id1 = int(input("Enter ID of person 1 to be removed as friend : "))
            id2 = int(input("Enter ID of person 2 to be removed as friend: "))

            records = a2.remove_friend(records,id1,id2)

            for i in range(len(records)):
                print(records[i])

        elif(n == 16):

            percentage = 0.0
            id1 = int(input("Enter ID of person whose education is being added : "))
            name = input('Enter institute name : ')
            ongoing = bool(input('Ongoing (Leave blank if false) : '))

            if (ongoing == False):
                while True:
                    try :
                        percentage = float(input("Enter the percentage : "))
                        break
                    except ValueError:
                        print("incorrect percentage, Try again")

            records = a2.add_education(records,id1,name,ongoing,percentage)
                
            for i in range(len(records)):
                print(records[i])
        
    else:
        print("incorrect query code")



    
